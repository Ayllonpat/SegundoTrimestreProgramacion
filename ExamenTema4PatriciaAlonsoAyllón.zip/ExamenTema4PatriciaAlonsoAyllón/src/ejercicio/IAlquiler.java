package ejercicio;

public interface IAlquiler {
	
	public double calcularPrecio(double cantidadBat);
	
}

package metodosPrivadosYDefault;

public interface IColegio {
	
	//mostrar que las personas se callan
	public static void mostrarSilencio() {
		
		System.out.println("Todos se callan");
		
	}
	
}

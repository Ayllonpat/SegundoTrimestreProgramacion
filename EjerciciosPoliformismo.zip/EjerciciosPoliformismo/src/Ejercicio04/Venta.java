package Ejercicio04;

public class Venta{
	
	public void generarListaProduuctosVendidos(ProductoGenerico[]lista) {
		
		for(int i = 0;i<lista.length;i++) {
			System.out.println(lista[i]);
		}
		
	}

}
